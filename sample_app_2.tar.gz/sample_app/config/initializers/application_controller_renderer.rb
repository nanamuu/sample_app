# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '9b328b6e7e493f7fc1411e68a26c0a2a629e3eac406ba348fa62e0881f9c0803a0f2f064fce1970ba01adf79b0c0f90c3bc52bdb9c1225399d20a910c2bf604b'